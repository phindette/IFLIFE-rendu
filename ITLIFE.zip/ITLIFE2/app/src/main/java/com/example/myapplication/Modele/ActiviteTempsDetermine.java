/*
package com.example.myapplication.Modele;

public class ActiviteTempsDetermine extends Activite {
    private int heure;

    public ActiviteTempsDetermine(String nom,int value){
        super(nom,value);
    }

    public ActiviteTempsDetermine(String nom,int value,int temps){
        super(nom,value);
        setHeure(temps);
    }

    public int getHeure(){
        return heure;
    }

    public void setHeure(int temps) {
        this.heure = temps;
    }
}
*/
