/*
package com.example.myapplication.Modele;

public class ActiviteTempsChoisis extends Activite{
    private int heure;

    public ActiviteTempsChoisis(String nom,int value,int temps){
        super(nom,value);
        setHeure(temps);
    }

    public int getHeure(){
        return heure;
    }

    public void setHeure(int temps) {
        this.heure = temps;
    }
}
*/
